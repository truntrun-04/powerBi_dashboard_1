# 📊 Power BI Sales Dashboard

![Power BI](https://img.shields.io/badge/Power%20BI-Dashboard-yellow?logo=powerbi)
![Excel](https://img.shields.io/badge/Data-Excel-green)
![Status](https://img.shields.io/badge/Project-Completed-brightgreen)

## 📌 Overview

This project demonstrates how Microsoft Power BI can transform raw sales data into an interactive dashboard for business decision-making.

The dashboard analyzes sales performance across different regions, product categories, and time periods using KPIs and interactive visualizations.

---

## 🚀 Features

- Interactive Dashboard
- KPI Cards
- Revenue Analysis
- Profit Analysis
- Regional Sales Analysis
- Product Category Analysis
- Monthly Sales Trend
- Dynamic Filters (Slicers)

---

## 🛠️ Tools Used

- Microsoft Power BI
- Microsoft Excel

---

## 📂 Dataset

The dataset contains:

- Order ID
- Order Date
- Region
- Category
- Product
- Sales
- Profit

---

## 📊 Dashboard Components

### KPI Cards

- Total Revenue
- Total Profit
- Total Orders

---

### Visualizations

- 📈 Monthly Sales Trend
- 📊 Sales by Region
- 🥧 Sales by Category
- 📉 Profit by Region
- 🏆 Top Selling Products

---

### Filters

- Region
- Category

---

## 📸 Dashboard Preview

### Complete Dashboard

![Dashboard](Screenshots/Dashboard.png)

---

### Sales by Region

![Sales by Region](Screenshots/Sales_by_Region.png)

---

### Sales by Category

![Sales by Category](Screenshots/Sales_by_Category.png)

---

### Monthly Sales Trend

![Monthly Sales](Screenshots/Monthly_Sales_Trend.png)

---

## 📈 Business Insights

- Electronics generated the highest revenue.
- North region recorded the maximum sales.
- Laptop was the best-selling product.
- Monthly sales remained stable with a slight increase towards the end of the month.
- Profit margins were highest in the Electronics category.

---

## 📂 Project Structure

```
PowerBI-Sales-Dashboard/
│
├── Dataset/
│   └── Sales_Data.xlsx
│
├── Dashboard/
│   └── Sales_Dashboard.pbix
│
├── Screenshots/
│
├── README.md
├── LICENSE
└── .gitignore
```

---

## ▶️ How to Use

1. Download the repository.
2. Open **Sales_Dashboard.pbix** in Microsoft Power BI Desktop.
3. Refresh the dataset if required.
4. Explore the dashboard using the slicers.

---

## 👨‍💻 Author

**Tarun Tanwar**

LinkedIn: https://www.linkedin.com/in/tarun-tanwar04/

GitHub: https://github.com/truntrun-04
